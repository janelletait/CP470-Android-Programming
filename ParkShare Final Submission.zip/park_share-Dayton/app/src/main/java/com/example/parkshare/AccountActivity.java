package com.example.parkshare;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class AccountActivity extends AppCompatActivity {
    Button updatePass, updateUser, updateUsernameButton;
    EditText curr_pass, new_pass, curr_username, new_username;
    TextView user, pass;
    private DBHelper dbh;
    private SQLiteDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account);
        user = (TextView)findViewById(R.id.StringUsername);
        pass = (TextView)findViewById(R.id.StringPassword);
        dbh = new DBHelper(this);
        database = dbh.getWritableDatabase();
        Cursor cursor = database.rawQuery("Select Email, Password from user_table where _id = ?", new String[]{String.valueOf(LoginActivity.ActiveID)});
        cursor.moveToFirst();
        user.setText(cursor.getString(cursor.getColumnIndexOrThrow("Email")));
        pass.setText(cursor.getString(cursor.getColumnIndexOrThrow("Password")));









        updatePass = (Button) findViewById(R.id.ButtonResetPassword);
        updateUser = (Button) findViewById(R.id.ButtonResetUsername);

        updatePass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showUpdatePassword();
            }
        });

        updateUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showUpdateUsername();
            }
        });
    }

    private void showUpdatePassword() {
        AlertDialog.Builder builder = new AlertDialog.Builder(AccountActivity.this);
        View view = LayoutInflater.from(AccountActivity.this).inflate(R.layout.dialog_update_pass, null);

        Button updatePasswordButton = (Button) view.findViewById(R.id.updatepass);
        curr_pass = (EditText)view.findViewById(R.id.currpass);
        new_pass = (EditText)view.findViewById(R.id.newpass);

        builder.setView(view);
        builder.create().show();

        updatePasswordButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pass = findViewById(R.id.StringPassword);
                if(curr_pass.getText().toString().equals(pass.getText().toString())) {
                    String old_pass_entered = curr_pass.getText().toString().trim();
                    String new_pass_entered = new_pass.getText().toString().trim();
                    updatePassword(new_pass_entered);


                }else {
                    Toast toast = Toast.makeText(AccountActivity.this, "Current password entered does not match, please try again", Toast.LENGTH_LONG);
                    toast.show();
                }
            }
        });

    }

    private void showUpdateUsername() {
        AlertDialog.Builder builder = new AlertDialog.Builder(AccountActivity.this);
        View view = LayoutInflater.from(AccountActivity.this).inflate(R.layout.dialog_update_user, null);

        builder.setView(view);
        builder.create().show();
        Button updateUsernameButton = (Button) view.findViewById(R.id.updateuser);
        new_username = (EditText)view.findViewById(R.id.newuser);

        updateUsernameButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (new_username.getText().toString().equals("") != true) {
                    String new_user_entered = new_username.getText().toString().trim();
                    updateUsername(new_user_entered);
                }
                else {
                    Toast.makeText(AccountActivity.this, "Please do not leave any fields blank!", Toast.LENGTH_SHORT);
                }
            }
        });


    }

    private void updatePassword(String newpass) {
        database = dbh.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DBHelper.COLUMN_PASSWORD, newpass);
        long result = database.update(DBHelper.TABLE_NAME, values, "_id=?", new String[]{String.valueOf(LoginActivity.ActiveID)});
        pass = (TextView) findViewById(R.id.StringPassword);
        pass.setText(newpass);
        if (result == -1) {
            Toast.makeText(AccountActivity.this, "Password failed to update!", Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(AccountActivity.this, "Password has been updated", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateUsername(String newuser) {
        database = dbh.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DBHelper.COLUMN_EMAIL, newuser);
        long result = database.update(DBHelper.TABLE_NAME, values, "_id=?", new String[]{String.valueOf(LoginActivity.ActiveID)});
        user = (TextView) findViewById(R.id.StringUsername);
        user.setText(newuser);
        if (result == -1) {
            Toast.makeText(AccountActivity.this, "Email failed to update!", Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(AccountActivity.this, "Email successfully updated!", Toast.LENGTH_SHORT).show();
        }
    }
    public void LogoutClicked(View v) {
        Intent intent = new Intent(AccountActivity.this, LoginActivity.class);
        startActivity(intent);
        finish();
    }

    @SuppressLint("ResourceType")
    public boolean onCreateOptionsMenu(Menu m){
        getMenuInflater().inflate(R.menu.toolbar_menu, m );
        return true;
    }


    public boolean onOptionsItemSelected(MenuItem mi) {
        int mi_id = mi.getItemId();
        switch (mi_id) {

            case R.id.settings:
                Log.d("Toolbar", "About Selected");
                //need to display the author’s name, Activity version number, and instructions for how to use the interface
                AlertDialog.Builder custom = new AlertDialog.Builder(AccountActivity.this);
                // Get the layout inflater
                LayoutInflater inflater = AccountActivity.this.getLayoutInflater();
                View view = inflater.inflate(R.layout.dialog_help_account, null);
                custom.setView(view);

                custom.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                    }
                });

                AlertDialog customdialog = custom.create();
                custom.show();
                break;
            case android.R.id.home:
                this.finish();
                return true;

        }
        return true;
    }
}